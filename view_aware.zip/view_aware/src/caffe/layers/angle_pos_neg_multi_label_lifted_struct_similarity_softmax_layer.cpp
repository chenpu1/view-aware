#include <algorithm>
#include <vector>
#include <iostream>
#include "caffe/layers/angle_pos_neg_multi_label_lifted_struct_similarity_softmax_layer.hpp"
#include "caffe/util/math_functions.hpp"
using namespace std;
namespace caffe {

template <typename Dtype>
void AnglePosNegMultiLabelLiftedStructSimilaritySoftmaxLossLayer<Dtype>::LayerSetUp(const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {

  LossLayer<Dtype>::LayerSetUp(bottom, top);
  CHECK_EQ(bottom[0]->height(), 1);
  CHECK_EQ(bottom[0]->width(), 1);
  CHECK_EQ(bottom[1]->height(), 1);
  CHECK_EQ(bottom[1]->width(), 1);  

  CHECK_EQ(bottom[2]->channels(), 1);   //class_label
  CHECK_EQ(bottom[2]->height(), 1);
  CHECK_EQ(bottom[2]->width(), 1);  
  CHECK_EQ(bottom[3]->channels(), 1);   //angle_label
  CHECK_EQ(bottom[3]->height(), 1);
  CHECK_EQ(bottom[3]->width(), 1);  
  // List of member variables defined in /include/caffe/loss_layers.hpp;
  //   diff_, dist_sq_, summer_vec_, loss_aug_inference_;
  dot_.Reshape(bottom[0]->num(), bottom[0]->num(), 1, 1);
  dist_sq1_.Reshape(bottom[0]->num(), 1, 1, 1);
  dot1_.Reshape(bottom[0]->num(), bottom[0]->num(), 1, 1);
  dist_sq2_.Reshape(bottom[0]->num(), 1, 1, 1);
  dot2_.Reshape(bottom[0]->num(), bottom[0]->num(), 1, 1);  
  ones_.Reshape(bottom[0]->num(), 1, 1, 1);  // n by 1 vector of ones.
  for (int i=0; i < bottom[0]->num(); ++i){
    ones_.mutable_cpu_data()[i] = Dtype(1);
  }
  blob_pos_diff_.Reshape(bottom[0]->channels(), 1, 1, 1);
  blob_neg_diff_.Reshape(bottom[0]->channels(), 1, 1, 1);

} 

template <typename Dtype>
void AnglePosNegMultiLabelLiftedStructSimilaritySoftmaxLossLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {
  nn = nn+1;
  cout<<"nn = "<<nn<<endl;
  int M_ = bottom[0]->num();
  int N_ = bottom[0]->num();
  int K_ = bottom[0]->channels();  
  const int channels = bottom[0]->channels();
  
  
  for (int i = 0; i < bottom[0]->num(); i++){
    dist_sq1_.mutable_cpu_data()[i] = caffe_cpu_dot(channels, bottom[0]->cpu_data() + (i*channels), bottom[0]->cpu_data() + (i*channels));
  }
  const Dtype* bottom_data1 = bottom[0]->cpu_data();
  const Dtype* bottom_data2 = bottom[0]->cpu_data();
  Dtype dot1_scaler(-2.0);
  caffe_cpu_gemm<Dtype>(CblasNoTrans, CblasTrans, M_, N_, K_, dot1_scaler, bottom_data1, bottom_data2, (Dtype)0., dot1_.mutable_cpu_data());

  // add ||x_i||^2 to all elements in row i
  for (int i=0; i<N_; i++){
    caffe_axpy(N_, dist_sq1_.cpu_data()[i], ones_.cpu_data(), dot1_.mutable_cpu_data() + i*N_);
  }
  // add the norm vector to row i
  for (int i=0; i<N_; i++){
    caffe_axpy(N_, Dtype(1.0), dist_sq1_.cpu_data(), dot1_.mutable_cpu_data() + i*N_);
  }


  for (int i = 0; i < bottom[0]->num(); i++){
    dist_sq2_.mutable_cpu_data()[i] = caffe_cpu_dot(channels, bottom[1]->cpu_data() + (i*channels), bottom[1]->cpu_data() + (i*channels));
  }
  const Dtype* bottom_data3 = bottom[1]->cpu_data();
  const Dtype* bottom_data4 = bottom[1]->cpu_data();

  Dtype dot2_scaler(-2.0);
  caffe_cpu_gemm<Dtype>(CblasNoTrans, CblasTrans, M_, N_, K_, dot2_scaler, bottom_data3, bottom_data4, (Dtype)0., dot2_.mutable_cpu_data());

  // add ||x_i||^2 to all elements in row i
  for (int i=0; i<N_; i++){
    caffe_axpy(N_, dist_sq2_.cpu_data()[i], ones_.cpu_data(), dot2_.mutable_cpu_data() + i*N_);
  }
  // add the norm vector to row i
  for (int i=0; i<N_; i++){
    caffe_axpy(N_, Dtype(1.0), dist_sq2_.cpu_data(), dot2_.mutable_cpu_data() + i*N_);
  }
  Dtype beta = this->layer_param_.angle_pos_neg_multi_label_lifted_struct_sim_softmax_loss_param().beta();  
  for (int i=0; i<N_; i++){
    for (int j=0; j<N_; j++){
      if(bottom[3]->cpu_data()[i] == bottom[3]->cpu_data()[j])
      {
		    dot_.mutable_cpu_data()[i*N_+j]  = dot1_.cpu_data()[i*N_+j];
      }
      if(bottom[3]->cpu_data()[i] != bottom[3]->cpu_data()[j])
      {
        dot_.mutable_cpu_data()[i*N_+j]  = dot2_.cpu_data()[i*N_+j]*beta*beta;
      }
    }
  }

  // construct pairwise label matrix

  Dtype margin = this->layer_param_.angle_pos_neg_multi_label_lifted_struct_sim_softmax_loss_param().margin();

  Dtype loss(0.0);
  num_constraints = Dtype(0.0); 
  const Dtype* bin1 = bottom[0]->cpu_data();
  const Dtype* bin2 = bottom[1]->cpu_data();

  Dtype* bout1 = bottom[0]->mutable_cpu_diff();
  Dtype* bout2 = bottom[1]->mutable_cpu_diff();
  // zero initialize bottom[0]->mutable_cpu_diff();
  for (int i=0; i<N_; i++){
    caffe_set(K_, Dtype(0.001), bout1 + i*K_);
  }
  for (int i=0; i<N_; i++){
    caffe_set(K_, Dtype(0.001), bout2 + i*K_);
  }    
  int num_negpair = 0;
  int num_pospair = 0;
  int right_pair = 0;
  Dtype acc = 0;
  Dtype dist_pos_end;
  
  vector<vector<bool> > label_mat(N_, vector<bool>(N_, false));
  for (int i=0; i<N_; i++){
    for (int j=0; j<N_; j++){
      label_mat[i][j] = (bottom[2]->cpu_data()[i] == bottom[2]->cpu_data()[j]);
    }
  }  
  // loop upper triangular matrix and look for positive anchors
  for (int i=0; i<N_; i++){
    for (int j=i+1; j<N_; j++){
	  
      // found a positive pair @ anchor (i, j)
      if (label_mat[i][j]){
    		num_pospair++;  
        Dtype dist_pos = sqrt(dot_.cpu_data()[i*N_ + j]);        
        //cout<<"dist_pos"<<dist_pos<<endl; 
        // 1.count the number of negatives for this positive
        int num_negatives = 0;
        for (int k=0; k<N_; k++){
          if (!label_mat[i][k]){
            //Dtype dist_neg = dot_.cpu_data()[i*N_ + k];        
            //cout<<"dist_neg"<<dist_neg<<endl; 
            num_negatives += 1;
          }
        }

        for (int k=0; k<N_; k++){
          if (!label_mat[j][k]){
            //Dtype dist_neg = dot_.cpu_data()[j*N_ + k];        
            //cout<<"dist_neg"<<dist_neg<<endl;           
            num_negatives += 1;
          }
        }

        loss_aug_inference_.Reshape(num_negatives, 1, 1, 1);

        // vector of ones used to sum along channels
        summer_vec_.Reshape(num_negatives, 1, 1, 1);
        for (int ss = 0; ss < num_negatives; ++ss){
          summer_vec_.mutable_cpu_data()[ss] = Dtype(1);
        }

        // 2. compute loss augmented inference
        int neg_idx = 0;
        // mine negative (anchor i, neg k)
        for (int k=0; k<N_; k++){
          if (!label_mat[i][k]){
            
            loss_aug_inference_.mutable_cpu_data()[neg_idx] = margin - sqrt(dot_.cpu_data()[i*N_ + k]);
            //cout<<"loss_aug_inference_.cpu_data()[neg_idx] = "<<loss_aug_inference_.cpu_data()[neg_idx]<<endl;
            if(loss_aug_inference_.cpu_data()[neg_idx]+dist_pos<0)
            {
              right_pair++;
            }
            neg_idx++;
            num_negpair++;
          }
        }

        // mine negative (anchor j, neg k)
        for (int k=0; k<N_; k++){
          if (!label_mat[j][k]){
            loss_aug_inference_.mutable_cpu_data()[neg_idx] = margin - sqrt(dot_.cpu_data()[j*N_ + k]);
            if(loss_aug_inference_.cpu_data()[neg_idx]+dist_pos<0)
            {
              right_pair++;
            }            
            neg_idx++;
            num_negpair++;
          }
        }

        // compute softmax of loss aug inference vector;
        Dtype max_elem = *std::max_element(loss_aug_inference_.cpu_data(), loss_aug_inference_.cpu_data() + num_negatives);

        caffe_add_scalar(loss_aug_inference_.count(), Dtype(-1.0)*max_elem, loss_aug_inference_.mutable_cpu_data());
        caffe_exp(loss_aug_inference_.count(), loss_aug_inference_.mutable_cpu_data(), loss_aug_inference_.mutable_cpu_data());
        Dtype soft_maximum = log(caffe_cpu_dot(num_negatives, summer_vec_.cpu_data(), loss_aug_inference_.mutable_cpu_data())) + max_elem;

        // hinge the soft_maximum - S_ij (positive pair similarity)
        Dtype this_loss = std::max(soft_maximum + dist_pos, Dtype(0.0));

        // squared hinge
        loss += this_loss * this_loss; 
        num_constraints += Dtype(1.0);
		

        // 3. compute gradients
		Dtype sum_exp = caffe_cpu_dot(num_negatives, summer_vec_.cpu_data(), loss_aug_inference_.mutable_cpu_data());
		Dtype scaler(0.0);
        if(bottom[3]->cpu_data()[i] == bottom[3]->cpu_data()[j])
        {
			caffe_sub(K_, bin1 + i*K_, bin1 + j*K_, blob_pos_diff_.mutable_cpu_data());		
			// update from positive distance dJ_dD_{ij}; update x_i, x_j			
			scaler = Dtype(2.0)*this_loss / dist_pos;
			// update x_i
			caffe_axpy(K_, scaler * Dtype(1.0), blob_pos_diff_.cpu_data(), bout1 + i*K_);
			// update x_j
			caffe_axpy(K_, scaler * Dtype(-1.0), blob_pos_diff_.cpu_data(), bout1 + j*K_);   
		}
        if(bottom[3]->cpu_data()[i] != bottom[3]->cpu_data()[j])
        {
			caffe_sub(K_, bin2 + i*K_, bin2 + j*K_, blob_pos_diff_.mutable_cpu_data());
			// update from positive distance dJ_dD_{ij}; update x_i, x_j
			scaler = Dtype(2.0)*this_loss / dist_pos;
			// update x_i
			caffe_axpy(K_, scaler * Dtype(1.0), blob_pos_diff_.cpu_data(), bout2 + i*K_);
			// update x_j
			caffe_axpy(K_, scaler * Dtype(-1.0), blob_pos_diff_.cpu_data(), bout2 + j*K_);   			
        }		
		// update from negative distance dJ_dD_{ik}; update x_i, x_k
		neg_idx = 0;
		Dtype dJ_dDik(0.0);
		for (int k=0; k<N_; k++){
		  if (!label_mat[i][k]){
			  if(bottom[3]->cpu_data()[i] == bottom[3]->cpu_data()[k])
			  {
				caffe_sub(K_, bin1 + i*K_, bin1 + k*K_, blob_neg_diff_.mutable_cpu_data());
	
				dJ_dDik = Dtype(2.0)*this_loss * Dtype(-1.0)* loss_aug_inference_.cpu_data()[neg_idx] / sum_exp;
				neg_idx++;
	
				scaler = dJ_dDik / sqrt(dot_.cpu_data()[i*N_ + k]);
	
				// update x_i
				caffe_axpy(K_, scaler * Dtype(1.0), blob_neg_diff_.cpu_data(), bout1 + i*K_);
				// update x_k
				caffe_axpy(K_, scaler * Dtype(-1.0), blob_neg_diff_.cpu_data(), bout1 + k*K_);
			  }
			  if(bottom[3]->cpu_data()[i] != bottom[3]->cpu_data()[k])
			  {
				caffe_sub(K_, bin2 + i*K_, bin2 + k*K_, blob_neg_diff_.mutable_cpu_data());
	
				dJ_dDik = Dtype(2.0)*this_loss * Dtype(-1.0)* loss_aug_inference_.cpu_data()[neg_idx] / sum_exp;
				neg_idx++;
	
				scaler = dJ_dDik / sqrt(dot_.cpu_data()[i*N_ + k]);
	
				// update x_i
				caffe_axpy(K_, scaler * Dtype(1.0), blob_neg_diff_.cpu_data(), bout2 + i*K_);
				// update x_k
				caffe_axpy(K_, scaler * Dtype(-1.0), blob_neg_diff_.cpu_data(), bout2 + k*K_);
			  }            
			}
		  }
  
		  // update from negative distance dJ_dD_{jk}; update x_j, x_k
		  Dtype dJ_dDjk(0.0);
		  for (int k=0; k<N_; k++){
			if (!label_mat[j][k]){
			  if(bottom[3]->cpu_data()[j] == bottom[3]->cpu_data()[k])
			  {
				caffe_sub(K_, bin1 + j*K_, bin1 + k*K_, blob_neg_diff_.mutable_cpu_data());
	
				dJ_dDjk = Dtype(2.0)*this_loss * Dtype(-1.0)*loss_aug_inference_.cpu_data()[neg_idx] / sum_exp;
				neg_idx++;
	
				scaler = dJ_dDjk / sqrt(dot_.cpu_data()[j*N_ + k]);
	
				// update x_j
				caffe_axpy(K_, scaler * Dtype(1.0), blob_neg_diff_.cpu_data(), bout1 + j*K_);
				// update x_k
				caffe_axpy(K_, scaler * Dtype(-1.0), blob_neg_diff_.cpu_data(), bout1 + k*K_);
			  }
			  if(bottom[3]->cpu_data()[j] != bottom[3]->cpu_data()[k])
			  {
				caffe_sub(K_, bin2 + j*K_, bin2 + k*K_, blob_neg_diff_.mutable_cpu_data());
	
				dJ_dDjk = Dtype(2.0)*this_loss * Dtype(-1.0)*loss_aug_inference_.cpu_data()[neg_idx] / sum_exp;
				neg_idx++;
	
				scaler = dJ_dDjk / sqrt(dot_.cpu_data()[j*N_ + k]);
	
				// update x_j
				caffe_axpy(K_, scaler * Dtype(1.0), blob_neg_diff_.cpu_data(), bout2 + j*K_);
				// update x_k
				caffe_axpy(K_, scaler * Dtype(-1.0), blob_neg_diff_.cpu_data(), bout2 + k*K_);
			  }            
			}
		  }             
		  
	    


      } // close this postive pair
    }
  }

  acc = Dtype(1.0)*right_pair/num_negpair;
  loss = loss / num_constraints / Dtype(2.0);
  top[0]->mutable_cpu_data()[0] = loss;

}

template <typename Dtype>
void AnglePosNegMultiLabelLiftedStructSimilaritySoftmaxLossLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
    const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom) {
  const Dtype alpha = top[0]->cpu_diff()[0] / num_constraints / Dtype(2.0);
  Dtype beta = this->layer_param_.angle_pos_neg_multi_label_lifted_struct_sim_softmax_loss_param().beta();  
  int num = bottom[0]->num();
  int channels = bottom[0]->channels();
  for (int i = 0; i < num; i++){
    Dtype* bout1 = bottom[0]->mutable_cpu_diff();
    caffe_scal(channels, alpha, bout1 + (i*channels));
    Dtype* bout2 = bottom[1]->mutable_cpu_diff();
    caffe_scal(channels, alpha*beta, bout2 + (i*channels));	
  }
}

#ifdef CPU_ONLY
STUB_GPU(AnglePosNegMultiLabelLiftedStructSimilaritySoftmaxLossLayer);
#endif

INSTANTIATE_CLASS(AnglePosNegMultiLabelLiftedStructSimilaritySoftmaxLossLayer);
REGISTER_LAYER_CLASS(AnglePosNegMultiLabelLiftedStructSimilaritySoftmaxLoss);

}  // namespace caffe



