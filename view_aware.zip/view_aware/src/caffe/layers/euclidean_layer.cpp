#include <vector>

#include "caffe/layers/euclidean_layer.hpp"
#include "caffe/util/math_functions.hpp"

namespace caffe {

template <typename Dtype>
void EuclideanLayer<Dtype>::Reshape(
  const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {
  
  CHECK_EQ(bottom[0]->count(1), bottom[1]->count(1))
      << "Inputs must have the same dimension.";
  diff_.ReshapeLike(*bottom[0]);
}

template <typename Dtype>
void EuclideanLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom,
    const vector<Blob<Dtype>*>& top) {
  int count = bottom[0]->count();
  int count1= bottom[0]->count(1);
  caffe_sub(
      count,
      bottom[0]->cpu_data(),
      bottom[1]->cpu_data(),
      diff_.mutable_cpu_data());
  Dtype dot[N_];
  for (int i=0;i<N_;i++)  
  {
      dot[i]=caffe_cpu_dot(count1, diff_.cpu_data()+i*count1, diff_.cpu_data()+i*count1);
      dot[i]=dot[i]/Dtype(2);
      top[0]->mutable_cpu_data()[i]=dot[i];
  }       
  
}

template <typename Dtype>
void EuclideanLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
    const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom) {
  for (int i = 0; i < 2; ++i) {
      if (propagate_down[i]) {    
        const Dtype sign = (i == 0) ? 1 : -1;                       
        for (int j=0;j<N_;j++) 
        {
        const Dtype alpha = sign * top[0]->cpu_diff()[j];
        caffe_cpu_axpby(
            bottom[i]->count(1),              // count
            alpha,                              // alpha
            diff_.cpu_data()+j*bottom[0]->count(1),  // a
            Dtype(0),                           // beta
            bottom[i]->mutable_cpu_diff()+j*bottom[0]->count(1));  // b
         
         }                  
      }  
  }

}

#ifdef CPU_ONLY
STUB_GPU(EuclideanLayer);
#endif

INSTANTIATE_CLASS(EuclideanLayer);
REGISTER_LAYER_CLASS(Euclidean);

}  // namespace caffe
