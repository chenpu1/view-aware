#include <algorithm>
#include <vector>
#include <iostream>
#include "caffe/layers/euclidean_dis_layer.hpp"
#include "caffe/util/math_functions.hpp"
using namespace std;
namespace caffe {

template <typename Dtype>
void EuclideanDisLayer<Dtype>::Reshape(const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {

}


template <typename Dtype>
void EuclideanDisLayer<Dtype>::LayerSetUp(const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {

  CHECK_EQ(bottom[0]->height(), 1);
  CHECK_EQ(bottom[0]->width(), 1);

  dist_sq_.Reshape(bottom[0]->num(), 1, 1, 1);
  top[0]->Reshape(bottom[0]->num(), bottom[0]->num(), 1, 1);
  //dot.Reshape(bottom[0]->num(), bottom[0]->num(), 1, 1);
  ones_.Reshape(bottom[0]->num(), 1, 1, 1);  // n by 1 vector of ones.
  for (int i=0; i < bottom[0]->num(); ++i){
    ones_.mutable_cpu_data()[i] = Dtype(1);
  }
  blob_diff_.Reshape(bottom[0]->channels(), 1, 1, 1);

} 

template <typename Dtype>
void EuclideanDisLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {
  Dtype* dot = top[0]->mutable_cpu_data();
  int M_ = bottom[0]->num();
  int N_ = bottom[0]->num();
  int K_ = bottom[0]->channels();

  const int channels = bottom[0]->channels();
  for (int i = 0; i < bottom[0]->num(); i++){
    dist_sq_.mutable_cpu_data()[i] = caffe_cpu_dot(channels, bottom[0]->cpu_data() + (i*channels), bottom[0]->cpu_data() + (i*channels));
  }
  const Dtype* bottom_data1 = bottom[0]->cpu_data();
  const Dtype* bottom_data2 = bottom[0]->cpu_data();

  Dtype dot_scaler(-2.0);
  caffe_cpu_gemm<Dtype>(CblasNoTrans, CblasTrans, M_, N_, K_, dot_scaler, bottom_data1, bottom_data2, (Dtype)0., dot);

  // add ||x_i||^2 to all elements in row i
  for (int i=0; i<N_; i++){
    caffe_axpy(N_, dist_sq_.cpu_data()[i], ones_.cpu_data(), dot + i*N_);
  }

  // add the norm vector to row i
  for (int i=0; i<N_; i++){
    caffe_axpy(N_, Dtype(1.0), dist_sq_.cpu_data(), dot + i*N_);
  }
  


}

template <typename Dtype>
void EuclideanDisLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
    const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom) {

  int N_ = bottom[0]->num();
  int K_ = bottom[0]->channels();
  const Dtype* dot_diff = top[0]->cpu_diff();
  const Dtype* bin = bottom[0]->cpu_data();
  Dtype* bout = bottom[0]->mutable_cpu_diff();
  for (int i=0; i<N_; i++){
    caffe_set(K_, Dtype(0.0), bout + i*K_);
  }  
  for(int i=0; i<N_; i++)
  {
	  for(int j=0; j<N_; j++)
	  {
		caffe_sub(K_, bin + i*K_, bin + j*K_, blob_diff_.mutable_cpu_data());
		Dtype scaler = Dtype(2.0)* dot_diff[i*N_+j];
		caffe_axpy(K_, scaler * Dtype(1.0), blob_diff_.cpu_data(), bout + i*K_);
		caffe_axpy(K_, scaler * Dtype(-1.0), blob_diff_.cpu_data(), bout + j*K_);
		
	  }
  }
}

#ifdef CPU_ONLY
STUB_GPU(EuclideanDisLayer);
#endif

INSTANTIATE_CLASS(EuclideanDisLayer);
REGISTER_LAYER_CLASS(EuclideanDis);

}  // namespace caffe



