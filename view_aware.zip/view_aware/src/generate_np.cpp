#include <vector>
#include <stdio.h>
#include <stdlib.h>

#include <typeinfo>

#include "caffe/layers/random.hpp"
#include "caffe/blob.hpp"

#include "caffe/util/math_functions.hpp"
using namespace caffe;

int max(int [], int);
int min(int [], int);

template <typename Dtype>
void generate_np(Blob<Dtype> sam, Blob<Dtype> neg_pairs,int label[],int num_np){
  //initial neg_pairs
  vector<int> data_shape(4,0);
  data_shape = sam.shape();
  const int N_ = data_shape[0],H_ = data_shape[2],W_ = data_shape[3];
  int   num_pairs = N_* num_np;
  neg_pairs.Reshape(num_pairs,2,H_,W_); 
  caffe_set(num_pairs*2*K_,Dtype(0.0),neg_pairs.mutable_cpu_data());
  // num_class
  int max_label = max(label, N_),min_label = min(label, N_);
  const int num_class = max_label - min_label+1;
  //num_sam
  vector<int> num_sam;
  int temp = 0;
  for(int i=0; i<num_class; i++){
	  for (int j=0; j<N_; j++){
			if (label[j] ==i)
				temp +=1;
	  }
	  num_sam.push_back(temp);
	  temp = 0;
  }
  //neg_pairs
  int K_ = H_*W_;
  Blob<Dtype> candi_neg;
  Blob<Dtype> candi_pos;
  int index_begin = 0,sam = 0;
  for(int i=0; i++; i<num_class){
	  // candi_pos
	  const int num = num_sam[i];
	  candi_pos.Reshape(num,1,H_,W_);
	  caffe_copy(num*K_, sam.cpu_data()[index_begin*K_], candi_pos.mutable_cpu_data());
	  //candi_neg
	  const int num_neg = N_-num;
	  candi_neg.Reshape(num_neg,1,H_,W_);
	  if (i==0){
		  caffe_copy((num_neg)*K_,sam.cpu_data()[num_sam[0]*K_],
        	  candi_neg.mutable_cpu_data())
	  }
	  else if(i==num_class-1){
		  caffe_copy((num_neg)*K_,sam.cpu_data(), candi_neg.mutable_cpu_data());
	  }
	  else{
		  caffe_copy(i*num*K_,sam.cpu_data(),candi_neg.mutable_cpu_data());
		  caffe_copy((num_class-i-1)*num*K_,sam.cpu_data()[(i+1)*num*K_],
		     candi_neg.mutable_cpu_data()[i*num*K_]);
	  }
	  //rand_id
	  int x[num_neg];
	  for (int i=0; i<num_neg; i++){
		  x[i]=i;
	  }
	  random(x,num_neg);
	  const int m = num*num_np;
	  double t = ceil(double(m)/double(num_neg));
	  const int s_ = t;
	  vector<int> rand_id;
	  for(int i=0; i<s_; i++){
		  for(int j=0; j<num_neg; j++){
			  rand_id.push_back(x[j]);
		  }
	  }
	  //neg_pairs
	  Blob<Dtype> S_neg;
	  S_neg.Reshape(m,2,H_,W_);
	  int idx = 0;
	  for(int i=0; i<num; i++){
		  for(int j=0; j<num_np; j++){
			  caffe_copy(K_,candi_pos.cpu_data()[i*K_],
			     S_neg.mutable_cpu_data()[idx*K_]);
			  //int h=rand_id[idx]*K_;
			  caffe_copy(K_,candi_neg.cpu_data()[rand_id[idx]*K_],
			     S_neg.mutable_cpu_data()[(idx+1)*K_]);
			  idx += 1;
		  }
	  }
	  caffe_copy(m*2*K_,S_neg.cpu_data(),neg_pairs.mutable_cpu_data()[sum*2*K_]);
	  sum += m;
	  index_begin += num; 
  }
}

int max(int a[], int n){
	int max_value = a[0];
	for (int i = 0; i<n ; i++){
		if (a[i]>max_value)
		max_value = a[i];
	}
	return(max_value);
}

int min(int a[], int n){
	int min_value=a[0];
	for (int i = 0; i<n - 1; i++){
		for (int i = 0; i<n; i++){
			if (a[i]<min_value)
				min_value = a[i];
		}
	}
	return(min_value);
}