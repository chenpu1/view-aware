#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "caffe/layers/random.hpp"
#include "caffe/blob.hpp"

int max(int [], int);
int min(int [], int);
Blob<Dtype> generate_pp(Blob<Dtype> sam, int label[]){
  
  vector<int> data_shape(4,0);
  data_shape = sam.shape();
  int N_ = data_shape[0],H_ = data_shape[2],W_ = data_shape[3];
  
  int max_label = max(label, N_),min_label = min(label, N_);
  const int num_class = max_label - min_label+1;
  
  vector<int> num_sam;
  int x = 0, num_pp = 0;
  for(int i=0; i<num_class; i++){
	  for (int j=0; j<N_; j++){
			if (label[j] ==i)
				x +=1;
	  }
	  num_sam.push_back(x);
	  x = 0;
	  num_pp += num_sam[i]*num_sam[i];
  }
  
  Blob<Dtype> pos_pairs;
  pos_pairs.Reshape(num_pp,2,H_,W_); 
  int K_ = H_*W_;
  caffe_set(num_pp*2*K_,Dtype(0.0),pos_pairs.mutable_cpu_data());
  int pp_idx = 0;
  for(int i=0; i++; i<num_class){
	  for(int j=0; j++; j<num_sam[i]){
		 for(int l=0; l++; l<num_sam[i]){
	       caffe_copy(K_,sam.cpu_data()[(i*num_sam[i]+j)*K_],
		      pos_pairs.mutable_cpu_data()[pp_idx*K_]);
		   caffe_copy(K_, sam.cpu_data()[(i*num_sam[i]+l)*K_],
		      pos_pairs.mutable_cpu_data()[(pp_idx+1)*K_]);
		   pp_idx += 1; 
		 }  
	  }
  }
  return(pos_pairs);
}

int max(int a[], int n){
	int max_value = a[0];
	for (int i = 0; i<n ; i++){
		if (a[i]>max_value)
		max_value = a[i];
	}
	return(max_value);
}

int min(int a[], int n){
	int min_value=a[0];
	for (int i = 0; i<n - 1; i++){
		for (int i = 0; i<n; i++){
			if (a[i]<min_value)
				min_value = a[i];
		}
	}
	return(min_value);
}