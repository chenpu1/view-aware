#ifndef CAFFE_EUCLIDEAN_DIS_LAYER_HPP_
#define CAFFE_EUCLIDEAN_DIS_LAYER_HPP_

#include <vector>

#include "caffe/blob.hpp"
#include "caffe/layer.hpp"
#include "caffe/proto/caffe.pb.h"


namespace caffe {

template <typename Dtype>
class EuclideanDisLayer : public Layer<Dtype> {
 public:
  explicit EuclideanDisLayer(const LayerParameter& param)
      : Layer<Dtype>(param) {}
  virtual void Reshape(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top);
  virtual void LayerSetUp(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top);
  virtual inline int ExactNumBottomBlobs() const { return 1; }
  virtual inline const char* type() const { return "EuclideanDis"; }
//  virtual inline bool AllowForceBackward(const int bottom_index) const {
//    return bottom_index != 1;
//  }

 protected:
  /// @copydoc euclidean_dis
  virtual void Forward_cpu(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top);

  virtual void Backward_cpu(const vector<Blob<Dtype>*>& top,
      const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom);

  Blob<Dtype> dist_sq_;  // cached for backward pass
  Blob<Dtype> ones_;
  Blob<Dtype> blob_diff_;
};

}  // namespace caffe

#endif  // CAFFE_EUCLIDEAN_DIS_LAYER_HPP_
