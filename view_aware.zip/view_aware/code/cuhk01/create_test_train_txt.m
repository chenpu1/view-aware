clc
clear
fprintf('create test..\n'); 
load('../../data/bmp_mat/cuhk01/new_test_label.mat')
load('../../data/bmp_mat/cuhk01/test_class.mat')
test_class_label = repmat(test_class,[4,1]);
test_class_label = reshape(test_class_label,[1,length(test_class_label)*4]);
if(exist('../../data/txt/cuhk01/test_images.txt','file'))
   delete('../../data/txt/cuhk01/test_images.txt')
end
f_id=fopen('../../data/txt/cuhk01/test_images.txt','wt');%�ڵ�ǰĿ¼��д�ķ�ʽ�򿪻򴴽�txt�ļ�
num = repmat([1,2,3,4],[1,100]);
for i=1:length(new_test_class_label)
   
  fprintf(f_id,['data/bmp_mat/cuhk01/test/',num2str(test_class_label(i)),'/',num2str(test_class_label(i),'%04d'),num2str(num(i),'%03d'),'.png ',num2str(new_test_class_label(i))]);
  fprintf(f_id,'\n');%����

end

fclose(f_id);%�ر��ļ�
fprintf('Done..\n');  

clc
clear
fprintf('create train..\n'); 
load('../../data/bmp_mat/cuhk01/new_train_label.mat')
load('../../data/bmp_mat/cuhk01/train_class.mat')
train_class_label = repmat(train_class,[4,1]);
train_class_label = reshape(train_class_label,[1,length(train_class_label)*4]);
if(exist('../../data/txt/cuhk01/train_images.txt','file'))
   delete('../../data/txt/cuhk01/train_images.txt')
end
f_id=fopen('../../data/txt/cuhk01/train_images.txt','wt');%�ڵ�ǰĿ¼��д�ķ�ʽ�򿪻򴴽�txt�ļ�
num = repmat([1,2,3,4],[1,871]);
for i=1:length(new_train_class_label)
   
  fprintf(f_id,['data/bmp_mat/cuhk01/train/',num2str(train_class_label(i)),'/',num2str(train_class_label(i),'%04d'),num2str(num(i),'%03d'),'.png ',num2str(new_train_class_label(i))]);
  fprintf(f_id,'\n');%����

end

fclose(f_id);%�ر��ļ�
fprintf('Done..\n');  



% clc
% clear
% fprintf('create train..\n'); 
% load('../data/bmp_mat/cuhk01/split_train_val_test/new_train_label.mat')
% if(exist('../data/txt/cuhk01/train_images_64.txt','file'))
%    delete('../data/txt/cuhk01/train_images_64.txt')
% end
% f_id=fopen('../data/txt/cuhk01/train_images_64.txt','wt');%�ڵ�ǰĿ¼��д�ķ�ʽ�򿪻򴴽�txt�ļ�
% num = repmat([1,2,3,4],[1,871]);
% for i=1:length(new_train_class_label)
%    
%   fprintf(f_id,['data/bmp_mat/cuhk01/train_images_64/',num2str(i),'.bmp ',num2str(new_train_class_label(i))]);
%   fprintf(f_id,'\n');%����
% 
% end
% 
% fclose(f_id);%�ر��ļ�
% fprintf('Done..\n'); 
