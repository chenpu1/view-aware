

clc
clear


mode = 'train';
batch_size = 32*1;
 


%% Load images 
load('../../data/bmp_mat/cuhk01/new_train_label.mat')
train_label = new_train_class_label;

%% Pick image pairs
assert(mod(batch_size, 2)==0);
[image_id_pairs, labels] = get_training_examples_multilabel(mode, batch_size,train_label);


% Caffe likes 0-1 labels
labels = int32(labels);
labels(labels == -1) = 0;


% Subtract 1 for C indexing
image_id_pairs = int32(image_id_pairs);

% check the number of paired data is divisible 

%% Do a morph before the mex file

image_id_pairs_serial = int32(zeros(numel(image_id_pairs), 1));
labels_serial = int32(zeros(length(labels)*2, 1));
 
insert_idx = 1;
lookup_idx = 1;
for i = 1:length(labels)
    if mod(i-1, (batch_size/2)) == 0
        image_id_pairs_serial(insert_idx : insert_idx + batch_size-1, :) = ...
            reshape(image_id_pairs(lookup_idx : lookup_idx + batch_size/2-1,:), [], 1);
        
        labels_serial(insert_idx : insert_idx + batch_size-1) = ...
            reshape(labels(lookup_idx : lookup_idx + batch_size/2 -1, :), [], 1);
        
        insert_idx = insert_idx + batch_size;
        lookup_idx = lookup_idx + batch_size/2;
    end
end
assert(length(image_id_pairs_serial) == 2*length(labels));
assert(mod(length(image_id_pairs_serial), batch_size)==0);
assert(min(image_id_pairs_serial)==1);
assert(max(image_id_pairs_serial)==length(train_label));
assert(length(labels_serial)==length(image_id_pairs_serial));
assert(train_label(image_id_pairs_serial(1))==labels_serial(1));
save ../../data/bmp_mat/cuhk01/training_image_id_pairs_serial image_id_pairs_serial labels_serial

load('../../data/bmp_mat/cuhk01/new_train_label.mat')
load('../../data/bmp_mat/cuhk01/train_class.mat')
train_class_label = repmat(train_class,[4,1]);
train_class_label = reshape(train_class_label,[1,length(train_class_label)*4]);
load('../../data/bmp_mat/cuhk01/training_image_id_pairs_serial.mat')
if(exist('../../data/txt/cuhk01/train_images_serial.txt','file'))
   delete('../../data/txt/cuhk01/train_images_serial.txt')
end
f_id=fopen('../../data/txt/cuhk01/train_images_serial.txt','wt');%在当前目录以写的方式打开或创建txt文件
num = repmat([1,2,3,4],[1,871]);
for i=1:length(labels_serial)
  fprintf(f_id,['data/bmp_mat/cuhk01/train/',num2str(train_class_label(image_id_pairs_serial(i))),'/',num2str(train_class_label(image_id_pairs_serial(i)),'%04d'),num2str(num(image_id_pairs_serial(i)),'%03d'),'.png ',num2str(labels_serial(i))]);   

    fprintf(f_id,'\n');%换行

end

fclose(f_id);%关闭文件
fprintf('Done ..\n');  


